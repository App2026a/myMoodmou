package gr.mymoodmou.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Rose = Color(0xFF9B6682)
private val Pale = Color(0xFFFAF0F5)
private val Ink = Color(0xFF563C4B)
private val moods = listOf(
    Mood("😊", "Χαρούμενη", 5), Mood("🥰", "Υπέροχα", 5),
    Mood("😌", "Ήρεμη", 4), Mood("🙂", "Καλά", 4),
    Mood("😐", "Ουδέτερη", 3), Mood("😴", "Κουρασμένη", 2),
    Mood("😰", "Αγχωμένη", 2), Mood("🥺", "Ευαίσθητη", 2),
    Mood("😔", "Στενοχωρημένη", 1), Mood("😡", "Θυμωμένη", 1)
)
data class Mood(val emoji: String, val label: String, val score: Int)
data class Entry(val time: Long, val slot: String, val emoji: String, val label: String, val score: Int, val note: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        scheduleDailyAlarms(this)
        setContent { MoodApp(this) }
    }
}

private fun prefs(c: Context) = c.getSharedPreferences("mymoodmou_local", Context.MODE_PRIVATE)
private fun readEntries(c: Context): List<Entry> {
    val arr = JSONArray(prefs(c).getString("entries", "[]"))
    return (0 until arr.length()).mapNotNull { i ->
        runCatching {
            val o = arr.getJSONObject(i)
            Entry(o.getLong("time"), o.getString("slot"), o.getString("emoji"),
                o.getString("label"), o.getInt("score"), o.optString("note"))
        }.getOrNull()
    }.sortedByDescending { it.time }
}
private fun saveEntry(c: Context, e: Entry) {
    val all = readEntries(c).toMutableList()
    all.add(e)
    val arr = JSONArray()
    all.sortedBy { it.time }.forEach {
        arr.put(JSONObject().put("time", it.time).put("slot", it.slot).put("emoji", it.emoji)
            .put("label", it.label).put("score", it.score).put("note", it.note))
    }
    prefs(c).edit().putString("entries", arr.toString())
        .putString("lastEmoji", e.emoji).apply()
}
private fun createNotificationChannel(c: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val channel = NotificationChannel("mood_reminders", "Υπενθυμίσεις διάθεσης", NotificationManager.IMPORTANCE_DEFAULT)
        channel.setSound(null, null)
        channel.enableVibration(false)
        c.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}
fun scheduleDailyAlarms(c: Context) {
    val alarm = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val times = listOf(7 to 0, 12 to 0, 18 to 0, 21 to 0, 23 to 0)
    times.forEachIndexed { index, hm ->
        val intent = Intent(c, MoodAlarmReceiver::class.java).putExtra("slotIndex", index)
        val pi = PendingIntent.getBroadcast(c, 700 + index, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hm.first); set(Calendar.MINUTE, hm.second)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis,
            AlarmManager.INTERVAL_DAY, pi)
    }
}

@Composable
fun MoodApp(context: Context) {
    var entries by remember { mutableStateOf(readEntries(context)) }
    var selected by remember { mutableStateOf(moods[0]) }
    var note by remember { mutableStateOf("") }
    var slot by remember { mutableStateOf("Πρωί – Ξύπνημα") }
    var tab by remember { mutableStateOf(0) }
    var period by remember { mutableStateOf("Εβδομάδα") }
    var showSaved by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    val lastEmoji = prefs(context).getString("lastEmoji", "🌷") ?: "🌷"
    val slots = listOf("Πρωί – Ξύπνημα", "Μέσα στη δουλειά", "Απόγευμα – Σπίτι", "Βράδυ – Χαλάρωση", "Πριν τον ύπνο")

    MaterialTheme(colorScheme = lightColorScheme(primary = Rose, background = Pale, surface = Color.White)) {
        Scaffold(containerColor = Pale, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Text("♡") }, label = { Text("Σήμερα") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Text("📊") }, label = { Text("Στατιστικά") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Text("📅") }, label = { Text("Ιστορικό") })
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(18.dp))
                Text("myMoodmou ♡", color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Πώς νιώθω σήμερα;", color = Rose, fontSize = 16.sp)
                Spacer(Modifier.height(12.dp))
                if (tab == 0) {
                    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(lastEmoji, fontSize = 48.sp)
                            Text("Η τελευταία σου διάθεση", color = Ink, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(12.dp))
                            HorizontalDivider(color = Pale)
                            Spacer(Modifier.height(12.dp))
                            Text("Πώς αισθάνεσαι αυτή τη στιγμή;", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Spacer(Modifier.height(10.dp))
                            slots.forEach { s ->
                                FilterChip(selected = slot == s, onClick = { slot = s }, label = { Text(s) })
                            }
                            Spacer(Modifier.height(8.dp))
                            MoodGrid(selected) { selected = it }
                            OutlinedTextField(value = note, onValueChange = { note = it },
                                label = { Text("Μια σκέψη σου (προαιρετικά)") },
                                placeholder = { Text("Γράψε μια πρόταση...") },
                                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), minLines = 2)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = {
                                saveEntry(context, Entry(System.currentTimeMillis(), slot, selected.emoji, selected.label, selected.score, note.trim()))
                                entries = readEntries(context); note = ""; showSaved = true
                            }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                                Text("Αποθήκευση διάθεσης")
                            }
                            if (showSaved) Text("Η διάθεσή σου αποθηκεύτηκε ♡", color = Rose)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("Οι σημερινές καταγραφές", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    val today = entries.filter { sameDay(it.time, System.currentTimeMillis()) }
                    today.take(5).forEach { EntryRow(it) }
                } else if (tab == 1) {
                    StatsScreen(entries, period, { period = it })
                } else {
                    Text("Το ημερολόγιό σου", color = Ink, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    LazyColumn {
                        items(entries) { EntryRow(it) }
                    }
                }
            }
        }
    }
}

@Composable
fun MoodGrid(selected: Mood, onSelect: (Mood) -> Unit) {
    Column {
        moods.chunked(5).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { mood ->
                    Column(Modifier.weight(1f).clickable { onSelect(mood) }
                        .background(if (mood == selected) Pale else Color.Transparent, RoundedCornerShape(14.dp))
                        .padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(mood.emoji, fontSize = 27.sp)
                        Text(mood.label, fontSize = 9.sp, color = Ink, maxLines = 1)
                    }
                }
            }
        }
    }
}
@Composable
fun EntryRow(e: Entry) {
    val date = SimpleDateFormat("dd/MM  HH:mm", Locale("el", "GR")).format(Date(e.time))
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(e.emoji, fontSize = 30.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(e.label, color = Ink, fontWeight = FontWeight.SemiBold)
                Text("${e.slot} • $date", color = Rose, fontSize = 11.sp)
                if (e.note.isNotBlank()) Text(e.note, color = Ink, fontSize = 12.sp)
            }
        }
    }
}
@Composable
fun StatsScreen(entries: List<Entry>, period: String, setPeriod: (String) -> Unit) {
    val now = System.currentTimeMillis()
    val days = when (period) { "Ημέρα" -> 1; "Εβδομάδα" -> 7; else -> 30 }
    val filtered = entries.filter { now - it.time < days * 24L * 60 * 60 * 1000 }
    val avg = if (filtered.isEmpty()) 0f else filtered.map { it.score }.average().toFloat()
    Text("Η εικόνα της διάθεσής σου", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("Ημέρα", "Εβδομάδα", "Μήνας").forEach {
            FilterChip(selected = period == it, onClick = { setPeriod(it) }, label = { Text(it) })
        }
    }
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("Μέση ένταση διάθεσης", color = Ink, fontWeight = FontWeight.Bold)
            Text(if (filtered.isEmpty()) "Δεν υπάρχουν ακόμη καταγραφές" else "Μέσος δείκτης: ${"%.1f".format(avg)} / 5", color = Rose)
            Spacer(Modifier.height(10.dp))
            Canvas(Modifier.fillMaxWidth().height(150.dp)) {
                val points = filtered.sortedBy { it.time }.takeLast(30)
                if (points.size > 1) {
                    val step = size.width / (points.size - 1)
                    val coords = points.mapIndexed { i, e ->
                        Offset(i * step, size.height - (e.score / 5f * size.height))
                    }
                    for (i in 0 until coords.lastIndex) drawLine(Rose, coords[i], coords[i+1], 5f, cap = StrokeCap.Round)
                    coords.forEach { drawCircle(Rose, 6f, it) }
                }
            }
            Text("Ο δείκτης είναι μια απλή προσωπική απεικόνιση, όχι ιατρική αξιολόγηση.", color = Color.Gray, fontSize = 11.sp)
        }
    }
    Spacer(Modifier.height(12.dp))
    Text("Συχνότερες διαθέσεις", color = Ink, fontWeight = FontWeight.Bold)
    val counts = filtered.groupBy { it.emoji to it.label }.mapValues { it.value.size }.entries.sortedByDescending { it.value }
    counts.forEach { (m, count) ->
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${m.key.first}  ${m.key.second}", modifier = Modifier.weight(1f), color = Ink)
            Text("$count φορές", color = Rose, fontWeight = FontWeight.SemiBold)
        }
    }
}

private fun sameDay(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a }
    val y = Calendar.getInstance().apply { timeInMillis = b }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}
