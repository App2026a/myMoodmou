package gr.mymoodmou.app

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class MoodAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val index = intent.getIntExtra("slotIndex", 0)
        val labels = listOf("Πρωί – Ξύπνημα", "Μέσα στη δουλειά", "Απόγευμα – Επιστροφή σπίτι", "Βράδυ – Χαλάρωση", "Πριν τον ύπνο")
        val open = PendingIntent.getActivity(context, 99, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(context, "mood_reminders") else Notification.Builder(context)
        val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("myMoodmou ♡")
            .setContentText("Πώς είναι τώρα η διάθεσή σου;")
            .setStyle(Notification.BigTextStyle().bigText("Πώς είναι τώρα η διάθεσή σου; ${labels.getOrElse(index) { "" }}"))
            .setContentIntent(open).setAutoCancel(true).build()
        context.getSystemService(NotificationManager::class.java).notify(700 + index, notification)
    }
}
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) scheduleDailyAlarms(context)
    }
}
